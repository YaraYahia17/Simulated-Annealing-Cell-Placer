import numpy as np
from PIL import Image # Pillow
import pygame
import sys

#intilize
def initStff(arr):
    pygame.init()
    #block dimensions
    blockWidth = 32
    blockHeight = 32

    #block number from array
    numBlockX = arr.shape[1] #columns
    numBlockY = arr.shape[0] #rows

    widthRes = numBlockX * blockWidth
    heighRes = numBlockY * blockHeight

    #colors
    white = (255,255,255)
    grey = (244,244,244)
    backgroundColor = grey

    #Window
    window = pygame.display.set_mode((widthRes, heighRes))
    window.fill(backgroundColor)

    return (window, blockWidth, blockHeight, numBlockX, numBlockY)

#text stuff
#print(pygame.font.get_fonts())


def drawGrid(surface, thickness, blockWidth, blockHeight, numBlockX, numBlockY):
  for i in range(numBlockX):
    pygame.draw.line(surface, (0,0,0), (i*blockWidth, 0), (i*blockWidth,numBlockY * blockHeight), thickness)
  for i in range(numBlockY):
    pygame.draw.line(surface, (0,0,0), (0, i*blockHeight), (numBlockX * blockWidth,i*blockHeight), thickness)


def drawNum(surface, arr, blockWidth, blockHeight, numBlockX, numBlockY):
    lightBlue = (173, 216, 230)
    font = pygame.font.SysFont('arial', 24)
    text = []
    for i in range(numBlockY):
        for j in range(numBlockX):
            if(arr[i][j] == -1):
                text = font.render( "  "  + "--" + "  ", True, (0,0,0))
            else:
                text = font.render( "  " + str(arr[i][j]) + "  ", True, (0,0,0), lightBlue)
                
            textRect = text.get_rect() 
            textRect.center = (blockWidth *j + blockWidth//2, blockHeight*i + blockHeight//2)

            surface.blit(text, textRect)

    #text = font.render(lineTexts[0], True, (0,0,0), lightBlue)
   # textRect = text.get_rect()
    #textRect.center = (widthRes // 2, heighRes // 2)
    return (text, textRect)


def saveAsImage(arr, imageNum):
    (window, blockWidth, blockHeight, numBlockX, numBlockY) = initStff(arr)
    drawNum(window, arr, blockWidth, blockHeight, numBlockX, numBlockY)
    #window.blit(text, textRect)
    drawGrid(window, 1, blockWidth, blockHeight, numBlockX, numBlockY)
    pygame.image.save(window,  str(imageNum) + ".jpg")
    pygame.display.update()




def main():
    #Define temp Arrays
    arr = np.array([
        [1, 2, 3, -1],
        [4, 3, -1, 0],
        [1, -1, -1, 3]
    ])
    
    imageNum = 0    
    saveAsImage(arr, imageNum)
    imageNum=imageNum+1
    

    '''
    drawGrid(window, 1, blockWidth, blockHeight, numBlockX, numBlockY)
    pygame.image.save(window,  str(imageNum) + ".jpg")
    pygame.display.update()

    while True:
        
        drawGrid(window, 1, blockWidth, blockHeight, numBlockX, numBlockY)

        #save the image
        count = count +1
        if(count > 6000):
            pygame.image.save(window,  str(imageNum) + ".jpg")
            imageNum = imageNum+1
            count=0
        

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                print("what?")
                sys.exit()
        '''
        

if __name__ == '__main__':
    main()
